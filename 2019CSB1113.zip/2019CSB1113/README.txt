# Mini-Project
Python program to suggest 'Friends You May Know' using anonymized facebook data that has been taken from https://snap.stanford.edu/data/

Extract user files from 'user_files' in the same folder, before running code.
Alternately, you may run add_random_data python file followed by creating_users python file before finally coming to Score&friendUpdate.py

Kindly perform either of the two steps only as failure to do so may lead to problems.

The input for Score&friendUpdate.py is simply an integer ranging from 0 to 4038.

The original data obtained from SNAP can be seen in facebook_combined.txt for reference.
